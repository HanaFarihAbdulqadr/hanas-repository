package com.example.caffe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
EditText user,pass;
Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        user=findViewById(R.id.txt_user);
        pass=findViewById(R.id.txt_password);

        login=findViewById(R.id.btn_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=user.getText().toString();
                String password=pass.getText().toString();

                if (username.equals("sakar")&& password.equals("sakar")){

                    startActivity(new Intent(getApplicationContext(), Setting.class) );

                } else if (!username.equals("sakar")&& password.equals("sakar")){

                    Toast.makeText(Login.this, "your username is incorrect", Toast.LENGTH_SHORT).show();
                }
                else if (username.equals("sakar")&& !password.equals("sakar")){

                    Toast.makeText(Login.this, "your password is incorrect", Toast.LENGTH_SHORT).show();
                } else if (!username.equals("sakar") && !password.equals("sakar")){

                    Toast.makeText(Login.this, "your yusername and password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}