package com.example.caffe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Cake extends AppCompatActivity {


    int[] image = {R.drawable.tralicha, R.drawable.cake_chokolate, R.drawable.despasito,R.drawable.lava_cake,R.drawable.lotus_cheescake,R.drawable.oreo_chescake,R.drawable.chescake_orange,R.drawable.lavender_cake,R.drawable.lavender_cake,R.drawable.lavender_cake,R.drawable.cheescake_tiramisu,R.drawable.cheescake_hanar};
    String[] cake_name = {"کێکیی ترالیچە", "کێکی چۆکۆلاتە","دێسپاسیتۆ","لاڤە کێک","چیس کێکی لۆتوس","چیس کێکی ئۆریۆ","چیس کێکی پرتەقاڵ","چیسکێکی بلوبێری","کێکی کەرەمێل","کێکی محەلەبی بە گوێز","کێکی تیرامیسۆ","چیسکێکی هەنار"};
    String[] cake_price = {"2000", "3000", "3000", "3000","3000","3000","3000","3000","3000","3000","3000","3000"};
     String amount[]=new String[12];



    ListView listCake;
    Button yes;
    TextView cake_name_list, cake_amount_list,cake_price_list;


    SharedPrefManager ob = new SharedPrefManager();

    SharedPrefManagerSetting obSetting = new SharedPrefManagerSetting();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake);

        listCake = (ListView) findViewById(R.id.list_cake);
        yes = (Button) findViewById(R.id.btn_yes);




        for (int i=0;i<cake_name.length;i++){
            int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(i).concat("cakeAmount"));
            amount[i]=Integer.toString(get_amount);

        }

         customAdapter customAdapter=new customAdapter();
         listCake.setAdapter(customAdapter);


         ///////////////////////la main pewistmana//////////////////////
      ob.setIntPrefVal(getApplicationContext(),"list_cake_chid_num",cake_name.length);

        ////////////////////////////////////////////////////////////////////////////

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                for (int i =0;i<listCake.getCount();i++){

                    View  v= getViewByPosition(i,listCake);
                    cake_name_list=(TextView)v.findViewById(R.id.name);
                    cake_amount_list =(TextView) v.findViewById(R.id.amount);
                    cake_price_list =(TextView)v.findViewById(R.id.price);

                    System.out.println(cake_name_list.getText().toString().concat(amount[i]));
                    if (!amount[i].equals(0)){
                        ob.setPrefVal(getApplicationContext(),Integer.toString(i).concat("cakeName"),cake_name_list.getText().toString());
                        ob.setIntPrefVal(getApplicationContext(),Integer.toString(i).concat("cakeAmount"),Integer.parseInt(cake_amount_list.getText().toString()));
                        ob.setIntPrefVal(getApplicationContext(),Integer.toString(i).concat("cakePrice"),Integer.parseInt(cake_price_list.getText().toString()));

                    }



                }
                startActivity(new Intent(getApplicationContext(), MainActivity.class) );

            }






        });




    }




    public View getViewByPosition(int position,ListView list){
        final int firstListItemPostion=list.getFirstVisiblePosition();
        final int lastListItemPostion=firstListItemPostion+list.getChildCount()-1;
        if (position<firstListItemPostion || position>lastListItemPostion){
            return list.getAdapter().getView(position,list.getChildAt(position),list);
        }else {
            final  int childIndex=position-firstListItemPostion;
            return list.getChildAt(childIndex);
        }
    }




    class customAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return cake_name.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }



        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

                view = getLayoutInflater().inflate(R.layout.activity_custom_listview, null);

            int get_avilable=obSetting.getIntPrefVal(getApplicationContext(),Integer.toString(i).concat("cake"));

                ImageView imageView = (ImageView) view.findViewById(R.id.img);
                TextView cake_name_list = (TextView) view.findViewById(R.id.name);
                TextView cake_price_list = (TextView) view.findViewById(R.id.price);
                ImageButton plus = (ImageButton) view.findViewById(R.id.b_plus);
                ImageButton minus = (ImageButton) view.findViewById(R.id.b_minus);
                TextView cake_amount_list = view.findViewById(R.id.amount);



                imageView.setImageResource(image[i]);
                cake_name_list.setText(cake_name[i]);
                if (get_avilable==0){
                    cake_name_list.setTextColor(Color.RED);
                }
                if (i==9){
                    cake_name_list.setTextSize(27);
                }
                cake_price_list.setText(cake_price[i]);
                cake_amount_list.setText(amount[i]);


                plus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (get_avilable==0) {
                        show_Alert();
                        }else{
                        int get_amount = Integer.parseInt(cake_amount_list.getText().toString());
                        get_amount++;
                        cake_amount_list.setText(Integer.toString(get_amount));
                        amount[i] = Integer.toString(get_amount);
                    }}


                });

                minus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int get_amount = Integer.parseInt(cake_amount_list.getText().toString());
                        if (get_amount < 0 || get_amount == 0) {
                            cake_amount_list.setText(Integer.toString(get_amount));
                            amount[i] = Integer.toString(get_amount);

                        } else {
                            get_amount--;
                            cake_amount_list.setText(Integer.toString(get_amount));
                            amount[i] = Integer.toString(get_amount);

                        }

                    }


                });



                return view;


        }


    }


    ///////////////////////////////////////////////////////////////////

    public  void show_Alert(){

        AlertDialog.Builder Alert=new AlertDialog.Builder(Cake.this);
       // Alert.setTitle("ڕونکردنەوە");
        Alert.setMessage("لە ئێستادا بەردەست نیە");
        Alert.show();
    }


    }
















