package com.example.caffe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class Setting extends AppCompatActivity {


    RadioButton yes_chokolate,no_chokolate,yes_tralicha,no_tralicha,yes_despasito,no_despasito,yes_lava,no_lava,yes_lotus,no_lotus,
            yes_orieo,no_orieo,yes_prtaqal,no_prtaqal,yes_bona,no_bona,yes_karamel,no_karamel,yes_mhalabi,no_mhalabi,yes_tramisu,no_tramisu,
    yes_cheescake_hanar,no_cheescake_hanar,

    yes_hlibard,no_hlibard,yes_xshxsh,no_xshxsh,yes_lwqmapasha,no_lwqmapasha
            ,yes_basbwsa,no_basbwsa,yestiramisu,no_tiramisu,yes_shOreio,no_shOrieo,yes_shLotus,no_shLotus,yes_magnolya,no_magnolya

   ,  yes_bchwk,no_bchwk,yes_wasat,no_wasat,yes_fstq_bchwk,no_fstq_bchwk,yes_fstq_wasat,no_fstq_wasat,
    yes_nutella_bchwk,no_nutella_bchwk,yes_nutella_wasat,no_nutella_wasat,



    yes_crepe_sada,no_crepe_sada,yes_crepe_moz,
    no_crepe_moz,yes_crepe_shlk,no_crepe_shlk,yes_crepe_oreo,no_crepe_oreo,yes_crepe_kinder,
            no_crepe_kinder,yes_crepe_mwshakal,no_crepe_mushakal,


    yes_freshprtaqal,no_freshprtaqal,yes_shirmoz,no_shirmoz,yes_kalak,no_kalak,yes_fqox,no_fqox,


    yes_cola,no_cola,yes_sprite,no_sprite,yes_tiger,no_tiger,yes_maksiky,no_maksiky,yes_ice,no_ice,
    yes_qazwan,no_qazwan, yes_turki,no_turki,yes_arabi,no_arabi,yes_esperso,no_esperso,yes_hotChokolet,no_hotChokolet,
    yes_americano,no_americano,yes_late,no_late,yes_capocino,no_capocino,yes_fstq,no_fstq,yes_gwez,no_gwez,

    yes_gelas,no_gelas, yes_qox,no_qox,yes_hanar,no_hanar,yes_blue,no_blue,yes_limo,no_limo,
    yes_bluecoraso,no_bluecoraso,yes_classic,no_classic,


    yes_smuzi_shlk,no_smuzi_shlk,yes_smuzi_blue,no_smuzi_blue,yes_smuzi_pasha,no_smuzi_pasha,
    yes_smuzi_moz,no_smuzi_moz,yes_smuzi_gelas,no_smuzi_gelas,yes_smuzi_qox,no_smuzi_qox,


    yes_kulicha,no_kulicha,yes_kunji,no_kunji,yes_shaklama,no_shaklama;

    Button yes;

    SharedPrefManagerSetting ob = new SharedPrefManagerSetting();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);


        yes_tralicha=findViewById(R.id.yes_tralicha);
        no_tralicha=findViewById(R.id.no_tralicha);
        yes_chokolate=findViewById(R.id.yes_shokolata);
        no_chokolate=findViewById(R.id.no_shokolata);
        yes_despasito=findViewById(R.id.yes_espasito);
        no_despasito=findViewById(R.id.no_despasito);
        yes_lava=findViewById(R.id.yes_lava);
        no_lava=findViewById(R.id.no_lava);
        yes_lotus=findViewById(R.id.yes_lotus);
        no_lotus=findViewById(R.id.no_lotus);
        yes_orieo=findViewById(R.id.yes_oreo);
        no_orieo=findViewById(R.id.no_orieo);
        yes_prtaqal=findViewById(R.id.yes_oreng);
        no_prtaqal=findViewById(R.id.no_orenge);
        yes_bona=findViewById(R.id.yes_bona);
        no_bona=findViewById(R.id.no_bona);
        yes_karamel=findViewById(R.id.yes_karamel);
        no_karamel=findViewById(R.id.no_karamel);
        yes_mhalabi=findViewById(R.id.yes_mhalabi);
        no_mhalabi=findViewById(R.id.no_mhalabi);
        yes_tramisu=findViewById(R.id.yes_tramisu);
        no_tramisu=findViewById(R.id.no_tramisu);
        yes_cheescake_hanar=findViewById(R.id.yes_chesscake_hanar);
        no_cheescake_hanar=findViewById(R.id.no_cheescake_hanar);

        yes_hlibard=findViewById(R.id.yes_hlibard);
        no_hlibard=findViewById(R.id.no_hlibard);
        yes_xshxsh=findViewById(R.id.yes_xshxsh);
        no_xshxsh=findViewById(R.id.no_xshxsh);
        yes_lwqmapasha=findViewById(R.id.yes_lwqmapash);
        no_lwqmapasha=findViewById(R.id.no_lwqmapasha);
        yes_basbwsa=findViewById(R.id.yes_basbwsa);
        no_basbwsa=findViewById(R.id.no_basbwsa);
        yestiramisu=findViewById(R.id.yes_tiramisu);
        no_tiramisu=findViewById(R.id.no_tiramisu);
        yes_shOreio=findViewById(R.id.yes_shOreio);
        no_shOrieo=findViewById(R.id.no_shOreio);
        yes_shLotus=findViewById(R.id.yes_shLotus);
        no_shLotus=findViewById(R.id.no_shotus);
        yes_magnolya=findViewById(R.id.yes_magnolya);
        no_magnolya=findViewById(R.id.no_magnolya);


        yes_bchwk=findViewById(R.id.yes_bchwk);
        no_bchwk=findViewById(R.id.no_bchwk);
        yes_wasat=findViewById(R.id.yes_gawra);
        no_wasat=findViewById(R.id.no_gawra);
        yes_fstq_bchwk=findViewById(R.id.yes_kwnafa_fstq);
        no_fstq_bchwk=findViewById(R.id.no_kwnafa_fstq);
        yes_fstq_wasat=findViewById(R.id.yes_kwnafa_fstq_wasat);
        no_fstq_wasat=findViewById(R.id.no_kwnafa_fstq_wasat);
        yes_nutella_bchwk=findViewById(R.id.yes_kunafa_nutella);
        no_nutella_bchwk=findViewById(R.id.no_kunafa_nutella);
        yes_nutella_wasat=findViewById(R.id.yes_kunafa_nutella_wasat);
        no_nutella_wasat=findViewById(R.id.no_kunafa_nutella_wasat);

        yes_crepe_sada=findViewById(R.id.yes_crepe_sada);
        no_crepe_sada=findViewById(R.id.no_crepe_sada);
        yes_crepe_moz=findViewById(R.id.yes_crepe_moz);
        no_crepe_moz=findViewById(R.id.no_crepe_moz);
        yes_crepe_shlk=findViewById(R.id.yes_crepe_shlk);
        no_crepe_shlk=findViewById(R.id.no_crepe_shlk);
        yes_crepe_oreo=findViewById(R.id.yes_crepe_oreo);
        no_crepe_oreo=findViewById(R.id.no_crepe_oreo);
        yes_crepe_kinder=findViewById(R.id.yes_crepe_kinder);
        no_crepe_kinder=findViewById(R.id.no_crepe_kinder);
        yes_crepe_mwshakal=findViewById(R.id.yes_crepe_mwshakal);
        no_crepe_mushakal=findViewById(R.id.no_crepe_mwshakal);

        yes_freshprtaqal=findViewById(R.id.yes_prtaqal);
        no_freshprtaqal=findViewById(R.id.no_prtaqal);
        yes_shirmoz=findViewById(R.id.yes_shirmoz);
        no_shirmoz=findViewById(R.id.no_shirmoz);
        yes_kalak=findViewById(R.id.yes_kalak);
        no_kalak=findViewById(R.id.no_kalak);
        yes_fqox=findViewById(R.id.yes_qox);
        no_fqox=findViewById(R.id.no_qox);


        yes_cola=findViewById(R.id.yes_cola);
        no_cola=findViewById(R.id.no_cola);
        yes_sprite=findViewById(R.id.yes_sprite);
        no_sprite=findViewById(R.id.no_sprite);
        yes_tiger=findViewById(R.id.yes_taigar);
        no_tiger=findViewById(R.id.no_taigar);
        yes_maksiky=findViewById(R.id.yes_maksiky);
        no_maksiky=findViewById(R.id.no_maksiky);
        yes_ice=findViewById(R.id.yes_ice);
        no_ice=findViewById(R.id.no_ice);

        yes_qazwan=findViewById(R.id.yes_qazwan);
        no_qazwan=findViewById(R.id.no_qazwan);
        yes_turki=findViewById(R.id.yes_turki);
        no_turki=findViewById(R.id.no_turki);
        yes_arabi=findViewById(R.id.yes_arabi);
        no_arabi=findViewById(R.id.no_arabi);
        yes_esperso=findViewById(R.id.yes_esperso);
        no_esperso=findViewById(R.id.no_esperso);
        yes_hotChokolet=findViewById(R.id.yes_hotChokolet);
        no_hotChokolet=findViewById(R.id.no_hotChokolet);
        yes_americano=findViewById(R.id.yes_americano);
        no_americano=findViewById(R.id.no_americano);
        yes_late=findViewById(R.id.yes_late);
        no_late=findViewById(R.id.no_late);
        yes_capocino=findViewById(R.id.yes_capocino);
        no_capocino=findViewById(R.id.no_capocino);
        yes_fstq=findViewById(R.id.yes_fstq);
        no_fstq=findViewById(R.id.no_fstq);
        yes_gwez=findViewById(R.id.yes_gwez);
        no_gwez=findViewById(R.id.no_gwez);


        yes_gelas=findViewById(R.id.yes_mohitogelas);
        no_gelas=findViewById(R.id.no_mohitogelas);
        yes_qox=findViewById(R.id.yes_mohitoqox);
        no_qox=findViewById(R.id.no_mohitoqox);
        yes_hanar=findViewById(R.id.yes_mohitohanar);
        no_hanar=findViewById(R.id.no_mohitohanar);
        yes_blue=findViewById(R.id.yes_mohitoblubery);
        no_blue=findViewById(R.id.no_mohitoblubery);
        yes_limo=findViewById(R.id.yes_limo);
        no_limo=findViewById(R.id.no_limon);
        yes_bluecoraso=findViewById(R.id.yes_mohitoblucoraso);
        no_bluecoraso=findViewById(R.id.no_mohitobluecoraso);
        yes_classic=findViewById(R.id.yes_mohitoclassic);
        no_classic=findViewById(R.id.no_mohitoclassic);

        yes_smuzi_shlk=findViewById(R.id.yes_smuzishlk);
        no_smuzi_shlk=findViewById(R.id.no_smuzishlk);
        yes_smuzi_blue=findViewById(R.id.yes_smuziblubery);
        no_smuzi_blue=findViewById(R.id.no_smuziblubery);
        yes_smuzi_pasha=findViewById(R.id.yes_pashafruty);
        no_smuzi_pasha=findViewById(R.id.no_pashafruty);
        yes_smuzi_moz=findViewById(R.id.yes_smuzimoz);
        no_smuzi_moz=findViewById(R.id.no_smuzimoz);
        yes_smuzi_gelas=findViewById(R.id.yes_smuzigelas);
        no_smuzi_gelas=findViewById(R.id.no_smuzigelas);
        yes_smuzi_qox=findViewById(R.id.yes_smuziqox);
        no_smuzi_qox=findViewById(R.id.no_smuziqox);


        yes_kulicha=findViewById(R.id.yes_kulicha);
        no_kulicha=findViewById(R.id.no_kulicha);
        yes_kunji=findViewById(R.id.yes_kunji);
        no_kunji=findViewById(R.id.no_kunji);
        yes_shaklama=findViewById(R.id.yes_shaklama);
        no_shaklama=findViewById(R.id.no_shaklama);
//////////////wargrtnaway bashi cake//////////////////////////////
for (int i_cake=0;i_cake<12;i_cake++){


    int get_state_cake=ob.getIntPrefVal(getApplicationContext(),Integer.toString(i_cake).concat("cake"));
            if ( get_state_cake==0 && i_cake==0){
                yes_tralicha.setChecked(false);
                no_tralicha.setChecked(true);

            }
            if (get_state_cake==1 && i_cake==0){
                yes_tralicha.setChecked(true);
                no_tralicha.setChecked(false);
            }

    if ( get_state_cake==0 && i_cake==1){
        yes_chokolate.setChecked(false);
        no_chokolate.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==1){
        yes_chokolate.setChecked(true);
        no_chokolate.setChecked(false);
    }

    if ( get_state_cake==0 && i_cake==2){
        yes_despasito.setChecked(false);
        no_despasito.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==2){
        yes_despasito.setChecked(true);
        no_despasito.setChecked(false);
    }

    if ( get_state_cake==0 && i_cake==3){
        yes_lava.setChecked(false);
        no_lava.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==3){
        yes_lava.setChecked(true);
        no_lava.setChecked(false);
    }

    if ( get_state_cake==0 && i_cake==4){
        yes_lotus.setChecked(false);
        no_lotus.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==4){
        yes_lotus.setChecked(true);
        no_lotus.setChecked(false);
    }
    if ( get_state_cake==0 && i_cake==5){
        yes_orieo.setChecked(false);
        no_orieo.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==5){
        yes_orieo.setChecked(true);
        no_orieo.setChecked(false);
    }
    if ( get_state_cake==0 && i_cake==6){
        yes_prtaqal.setChecked(false);
        no_prtaqal.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==6){
        yes_prtaqal.setChecked(true);
        no_prtaqal.setChecked(false);
    }
    if ( get_state_cake==0 && i_cake==7){
        yes_bona.setChecked(false);
        no_bona.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==7){
        yes_bona.setChecked(true);
        no_bona.setChecked(false);
    }


    if ( get_state_cake==0 && i_cake==8){
        yes_karamel.setChecked(false);
        no_karamel.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==8){
        yes_karamel.setChecked(true);
        no_karamel.setChecked(false);
    }


    if ( get_state_cake==0 && i_cake==9){
        yes_mhalabi.setChecked(false);
        no_mhalabi.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==9){
        yes_mhalabi.setChecked(true);
        no_mhalabi.setChecked(false);
    }



    if ( get_state_cake==0 && i_cake==10){
        yes_tramisu.setChecked(false);
        no_tramisu.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==10){
        yes_tramisu.setChecked(true);
        no_tramisu.setChecked(false);
    }

    if ( get_state_cake==0 && i_cake==11){
        yes_cheescake_hanar.setChecked(false);
        no_cheescake_hanar.setChecked(true);

    }
    if (get_state_cake==1 && i_cake==11){
        yes_cheescake_hanar.setChecked(true);
        no_cheescake_hanar.setChecked(false);
    }



}


////////////////wargrtnawai bashi sweet//////////////////////

        for (int iSweet=0;iSweet<8;iSweet++){


            int get_state_sweet=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iSweet).concat("sweet"));
            if ( get_state_sweet==0 && iSweet==0){
                yes_hlibard.setChecked(false);
                no_hlibard.setChecked(true);

            }
            if (get_state_sweet==1 && iSweet==0){
                yes_hlibard.setChecked(true);
                no_hlibard.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==1){
                yes_xshxsh.setChecked(false);
                no_xshxsh.setChecked(true);

            }
            if (get_state_sweet==1 && iSweet==1){
                yes_xshxsh.setChecked(true);
                no_xshxsh.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==2){
                yes_lwqmapasha.setChecked(false);
                no_lwqmapasha.setChecked(true);

            }
            if (get_state_sweet==1 && iSweet==2){
                yes_lwqmapasha.setChecked(true);
                no_lwqmapasha.setChecked(false);
            }

            if (get_state_sweet==1 && iSweet==3){
                yes_basbwsa.setChecked(true);
                no_basbwsa.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==3){
                yes_basbwsa.setChecked(false);
                no_basbwsa.setChecked(true);

            }
            if (get_state_sweet==1 && iSweet==4){
                yestiramisu.setChecked(true);
                no_tiramisu.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==4){
                yestiramisu.setChecked(false);
                no_tiramisu.setChecked(true);

            }

            if (get_state_sweet==1 && iSweet==5){
                yes_shOreio.setChecked(true);
                no_shOrieo.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==5){
                yes_shOreio.setChecked(false);
                no_shOrieo.setChecked(true);

            }


            if (get_state_sweet==1 && iSweet==6){
                yes_shLotus.setChecked(true);
                no_shLotus.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==6){
                yes_shLotus.setChecked(false);
                no_shLotus.setChecked(true);

            }
            if (get_state_sweet==1 && iSweet==7){
                yes_magnolya.setChecked(true);
                no_magnolya.setChecked(false);
            }

            if ( get_state_sweet==0 && iSweet==7){
                yes_magnolya.setChecked(false);
                no_magnolya.setChecked(true);

            }
        }


/////////////////////////////wargrtnawai bashi kunafa///////////////////////

        for (int iKunafa=0;iKunafa<6;iKunafa++){


            int get_state_kunafa=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iKunafa).concat("kunafa"));
            if ( get_state_kunafa==0 && iKunafa==0){
                yes_bchwk.setChecked(false);
                no_bchwk.setChecked(true);

            }
            if (get_state_kunafa==1 && iKunafa==0){
                yes_bchwk.setChecked(true);
                no_bchwk.setChecked(false);
            }

            if ( get_state_kunafa==0 && iKunafa==1){
                yes_wasat.setChecked(false);
                no_wasat.setChecked(true);

            }
            if (get_state_kunafa==1 && iKunafa==1){
                yes_wasat.setChecked(true);
                no_wasat.setChecked(false);
            }

            if ( get_state_kunafa==0 && iKunafa==2){
                yes_fstq_bchwk.setChecked(false);
                no_fstq_bchwk.setChecked(true);

            }
            if (get_state_kunafa==1 && iKunafa==2){
                yes_fstq_bchwk.setChecked(true);
                no_fstq_bchwk.setChecked(false);
            }

            if (get_state_kunafa==1 && iKunafa==3){
                yes_fstq_wasat.setChecked(true);
                no_fstq_wasat.setChecked(false);
            }

            if ( get_state_kunafa==0 && iKunafa==3){
                yes_fstq_wasat.setChecked(false);
                no_fstq_wasat.setChecked(true);

            }
            if (get_state_kunafa==1 && iKunafa==4){
                yes_nutella_bchwk.setChecked(true);
                no_nutella_bchwk.setChecked(false);
            }

            if ( get_state_kunafa==0 && iKunafa==4){
                yes_nutella_bchwk.setChecked(false);
                no_nutella_bchwk.setChecked(true);

            }
            if (get_state_kunafa==1 && iKunafa==5){
                yes_nutella_wasat.setChecked(true);
                no_nutella_wasat.setChecked(false);
            }

            if ( get_state_kunafa==0 && iKunafa==5){
                yes_nutella_wasat.setChecked(false);
                no_nutella_wasat.setChecked(true);

            }
        }
//////////////////////////////////////wargrtnawai bashi crepe//////////////////////

        for (int icrepe=0;icrepe<6;icrepe++){


            int get_state_crepe=ob.getIntPrefVal(getApplicationContext(),Integer.toString(icrepe).concat("crepe"));
            if ( get_state_crepe==0 && icrepe==0){
                yes_crepe_sada.setChecked(false);
                no_crepe_sada.setChecked(true);

            }
            if (get_state_crepe==1 && icrepe==0){
                yes_crepe_sada.setChecked(true);
                no_crepe_sada.setChecked(false);
            }

            if ( get_state_crepe==0 && icrepe==1){
                yes_crepe_moz.setChecked(false);
                no_crepe_moz.setChecked(true);

            }
            if (get_state_crepe==1 && icrepe==1){
                yes_crepe_moz.setChecked(true);
                no_crepe_moz.setChecked(false);
            }

            if ( get_state_crepe==0 && icrepe==2){
                yes_crepe_shlk.setChecked(false);
                no_crepe_shlk.setChecked(true);

            }
            if (get_state_crepe==1 && icrepe==2){
                yes_crepe_shlk.setChecked(true);
                no_crepe_shlk.setChecked(false);
            }

            if (get_state_crepe==1 && icrepe==3){
                yes_crepe_oreo.setChecked(true);
                no_crepe_oreo.setChecked(false);
            }

            if ( get_state_crepe==0 && icrepe==3){
                yes_crepe_oreo.setChecked(false);
                no_crepe_oreo.setChecked(true);

            }
            if (get_state_crepe==1 && icrepe==4){
                yes_crepe_kinder.setChecked(true);
                no_crepe_kinder.setChecked(false);
            }

            if ( get_state_crepe==0 && icrepe==4){
                yes_crepe_kinder.setChecked(false);
                no_crepe_kinder.setChecked(true);

            }

            if (get_state_crepe==1 && icrepe==5){
                yes_crepe_mwshakal.setChecked(true);
                no_crepe_mushakal.setChecked(false);
            }

            if ( get_state_crepe==0 && icrepe==5){
                yes_crepe_mwshakal.setChecked(false);
                no_crepe_mushakal.setChecked(true);

            }
        }



        //////////////////////////////////////wargrtnawai bashi fresh//////////////////////

        for (int ifresh=0;ifresh<4;ifresh++) {


            int get_state_fresh = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ifresh).concat("fresh"));
            if (get_state_fresh == 0 && ifresh == 0) {
                yes_freshprtaqal.setChecked(false);
                no_freshprtaqal.setChecked(true);

            }
            if (get_state_fresh == 1 && ifresh == 0) {
                yes_freshprtaqal.setChecked(true);
                no_freshprtaqal.setChecked(false);
            }

            if (get_state_fresh == 0 && ifresh == 1) {
                yes_shirmoz.setChecked(false);
                no_shirmoz.setChecked(true);

            }
            if (get_state_fresh == 1 && ifresh == 1) {
                yes_shirmoz.setChecked(true);
                no_shirmoz.setChecked(false);
            }

            if (get_state_fresh == 0 && ifresh == 2) {
                yes_kalak.setChecked(false);
                no_kalak.setChecked(true);

            }
            if (get_state_fresh == 1 && ifresh == 2) {
                yes_kalak.setChecked(true);
                no_kalak.setChecked(false);
            }

            if (get_state_fresh == 0 && ifresh == 3) {
                yes_fqox.setChecked(false);
                no_fqox.setChecked(true);

            }
            if (get_state_fresh == 1 && ifresh == 3) {
                yes_fqox.setChecked(true);
                no_fqox.setChecked(false);
            }
        }




        //////////////////////////////////////wargrtnawai bashi ice//////////////////////

        for (int iice=0;iice<5;iice++) {


            int get_state_ice = ob.getIntPrefVal(getApplicationContext(), Integer.toString(iice).concat("xwardnawa"));
            if (get_state_ice == 0 && iice == 0) {
                yes_cola.setChecked(false);
                no_cola.setChecked(true);

            }
            if (get_state_ice == 1 && iice == 0) {
                yes_cola.setChecked(true);
                no_cola.setChecked(false);
            }

            if (get_state_ice == 0 && iice == 1) {
                yes_sprite.setChecked(false);
                no_sprite.setChecked(true);

            }
            if (get_state_ice == 1 && iice == 1) {
                yes_sprite.setChecked(true);
                no_sprite.setChecked(false);
            }

            if (get_state_ice == 0 && iice == 2) {
                yes_tiger.setChecked(false);
                no_tiger.setChecked(true);

            }
            if (get_state_ice == 1 && iice == 2) {
                yes_tiger.setChecked(true);
                no_tiger.setChecked(false);
            }
            if (get_state_ice == 0 && iice == 3) {
                yes_maksiky.setChecked(false);
                no_maksiky.setChecked(true);

            }
            if (get_state_ice == 1 && iice == 3) {
                yes_maksiky.setChecked(true);
                no_maksiky.setChecked(false);
            }
            if (get_state_ice == 0 && iice == 4) {
                yes_ice.setChecked(false);
                no_ice.setChecked(true);

            }
            if (get_state_ice == 1 && iice == 4) {
                yes_ice.setChecked(true);
                no_ice.setChecked(false);
            }
        }
//////////////wargrtnaway bashi hot//////////////////////////////
            for (int i_hot=0;i_hot<10;i_hot++){


                int get_state_xwardnawayGarm=ob.getIntPrefVal(getApplicationContext(),Integer.toString(i_hot).concat("hot"));
                if ( get_state_xwardnawayGarm==0 && i_hot==0){
                    yes_qazwan.setChecked(false);
                    no_qazwan.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==0){
                    yes_qazwan.setChecked(true);
                    no_qazwan.setChecked(false);
                }

                if ( get_state_xwardnawayGarm==0 && i_hot==1){
                    yes_turki.setChecked(false);
                    no_turki.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==1){
                    yes_turki.setChecked(true);
                    no_turki.setChecked(false);
                }

                if ( get_state_xwardnawayGarm==0 && i_hot==2){
                    yes_arabi.setChecked(false);
                    no_arabi.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==2){
                    yes_arabi.setChecked(true);
                    no_arabi.setChecked(false);
                }

                if ( get_state_xwardnawayGarm==0 && i_hot==3){
                    yes_esperso.setChecked(false);
                    no_esperso.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==3){
                    yes_esperso.setChecked(true);
                    no_esperso.setChecked(false);
                }

                if ( get_state_xwardnawayGarm==0 && i_hot==4){
                    yes_hotChokolet.setChecked(false);
                    no_hotChokolet.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==4){
                    yes_hotChokolet.setChecked(true);
                    no_hotChokolet.setChecked(false);
                }
                if ( get_state_xwardnawayGarm==0 && i_hot==5){
                    yes_americano.setChecked(false);
                    no_americano.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==5){
                    yes_americano.setChecked(true);
                    no_americano.setChecked(false);
                }
                if ( get_state_xwardnawayGarm==0 && i_hot==6){
                    yes_late.setChecked(false);
                    no_late.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==6){
                    yes_late.setChecked(true);
                    no_late.setChecked(false);
                }
                if ( get_state_xwardnawayGarm==0 && i_hot==7){
                    yes_capocino.setChecked(false);
                    no_capocino.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==7){
                    yes_capocino.setChecked(true);
                    no_capocino.setChecked(false);
                }

                if ( get_state_xwardnawayGarm==0 && i_hot==8){
                    yes_fstq.setChecked(false);
                    no_fstq.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==8){
                    yes_fstq.setChecked(true);
                    no_fstq.setChecked(false);
                } if ( get_state_xwardnawayGarm==0 && i_hot==9){
                    yes_gwez.setChecked(false);
                    no_gwez.setChecked(true);

                }
                if (get_state_xwardnawayGarm==1 && i_hot==9){
                    yes_gwez.setChecked(true);
                    no_gwez.setChecked(false);
                }

            }


////////////////wargrtnawai bashi mohito//////////////////////

            for (int iMohito=0;iMohito<7;iMohito++){


                int get_state_mohitosweet=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iMohito).concat("mohito"));
                if ( get_state_mohitosweet==0 && iMohito==0){
                    yes_gelas.setChecked(false);
                    no_gelas.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==0){
                    yes_gelas.setChecked(true);
                    no_gelas.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==1){
                    yes_qox.setChecked(false);
                    no_qox.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==1){
                    yes_qox.setChecked(true);
                    no_qox.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==2){
                    yes_hanar.setChecked(false);
                    no_hanar.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==2){
                    yes_hanar.setChecked(true);
                    no_hanar.setChecked(false);
                }

                if (get_state_mohitosweet==1 && iMohito==3){
                    yes_blue.setChecked(true);
                    no_blue.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==3){
                    yes_blue.setChecked(false);
                    no_blue.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==4){
                    yes_limo.setChecked(true);
                    no_limo.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==4){
                    yes_limo.setChecked(false);
                    no_limo.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==5){
                    yes_bluecoraso.setChecked(true);
                    no_bluecoraso.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==5){
                    yes_bluecoraso.setChecked(false);
                    no_bluecoraso.setChecked(true);

                }
                if (get_state_mohitosweet==1 && iMohito==6){
                    yes_classic.setChecked(true);
                    no_classic.setChecked(false);
                }

                if ( get_state_mohitosweet==0 && iMohito==6){
                    yes_classic.setChecked(false);
                    no_classic.setChecked(true);

                }
            }

///////////////wargrtnawai bashi smuzi//////////////////////

            for (int iSmuzi=0;iSmuzi<6;iSmuzi++){


                int get_state_smuzi=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iSmuzi).concat("smuzi"));
                if ( get_state_smuzi==0 && iSmuzi==0){
                    yes_smuzi_shlk.setChecked(false);
                    no_smuzi_shlk.setChecked(true);

                }
                if (get_state_smuzi==1 && iSmuzi==0){
                    yes_smuzi_shlk.setChecked(true);
                    no_smuzi_shlk.setChecked(false);
                }

                if ( get_state_smuzi==0 && iSmuzi==1){
                    yes_smuzi_blue.setChecked(false);
                    no_smuzi_blue.setChecked(true);

                }
                if (get_state_smuzi==1 && iSmuzi==1){
                    yes_smuzi_blue.setChecked(true);
                    no_smuzi_blue.setChecked(false);
                }

                if ( get_state_smuzi==0 && iSmuzi==2){
                    yes_smuzi_pasha.setChecked(false);
                    no_smuzi_pasha.setChecked(true);

                }
                if (get_state_smuzi==1 && iSmuzi==2){
                    yes_smuzi_pasha.setChecked(true);
                    no_smuzi_pasha.setChecked(false);
                }

                if (get_state_smuzi==1 && iSmuzi==3){
                    yes_smuzi_moz.setChecked(true);
                    no_smuzi_moz.setChecked(false);
                }

                if ( get_state_smuzi==0 && iSmuzi==3){
                    yes_smuzi_moz.setChecked(false);
                    no_smuzi_moz.setChecked(true);

                }
                if (get_state_smuzi==1 && iSmuzi==4){
                    yes_smuzi_gelas.setChecked(true);
                    no_smuzi_gelas.setChecked(false);
                }

                if ( get_state_smuzi==0 && iSmuzi==4){
                    yes_smuzi_gelas.setChecked(false);
                    no_smuzi_gelas.setChecked(true);

                }
                if (get_state_smuzi==1 && iSmuzi==5){
                    yes_smuzi_qox.setChecked(true);
                    no_smuzi_qox.setChecked(false);
                }

                if ( get_state_smuzi==0 && iSmuzi==5){
                    yes_smuzi_qox.setChecked(false);
                    no_smuzi_qox.setChecked(true);

                }

            }


            ////////////////wargrtnawai bashi shirini wshk//////////////////////

            for (int iShirini=0;iShirini<5;iShirini++){


                int get_state_shirini=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iShirini).concat("shirini"));
                if ( get_state_shirini==0 && iShirini==0){
                    yes_kulicha.setChecked(false);
                    no_kulicha.setChecked(true);

                }
                if (get_state_shirini==1 && iShirini==0){
                    yes_kulicha.setChecked(true);
                    no_kulicha.setChecked(false);
                }

                if ( get_state_shirini==0 && iShirini==1){
                    yes_kunji.setChecked(false);
                    no_kunji.setChecked(true);

                }
                if (get_state_shirini==1 && iShirini==1){
                    yes_kunji.setChecked(true);
                    no_kunji.setChecked(false);
                }

                if ( get_state_shirini==0 && iShirini==2){
                    yes_shaklama.setChecked(false);
                    no_shaklama.setChecked(true);

                }
                if (get_state_shirini==1 && iShirini==2){
                    yes_shaklama.setChecked(true);
                    no_shaklama.setChecked(false);
                }


            }


            ////////////////////////////////////////////////////////////////

        yes=findViewById(R.id.btn_yes);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (yes_tralicha.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("cake"),1);

                }else if (no_tralicha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("cake"), 0);
                }
                if (yes_chokolate.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("cake"),1);

                }else if (no_chokolate.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("cake"), 0);
                }

                if (yes_despasito.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("cake"),1);

                }else if (no_despasito.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("cake"), 0);
                }


                if (yes_lava.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("cake"),1);

                }else if (no_lava.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("cake"), 0);
                }


                if (yes_lotus.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("cake"),1);

                }else if (no_lotus.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("cake"), 0);
                }


                if (yes_orieo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("cake"),1);

                }else if (no_orieo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("cake"), 0);
                }


                if (yes_prtaqal.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(6).concat("cake"),1);

                }else if (no_prtaqal.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(6).concat("cake"), 0);
                }


                if (yes_bona.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(7).concat("cake"),1);

                }else if (no_bona.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(7).concat("cake"), 0);
                }


                if (yes_karamel.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(8).concat("cake"),1);

                }else if (no_karamel.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(8).concat("cake"), 0);
                }
                if (yes_mhalabi.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(9).concat("cake"),1);

                }else if (no_mhalabi.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(9).concat("cake"), 0);
                }

                if (yes_tramisu.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(10).concat("cake"),1);

                }else if (no_tramisu.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(10).concat("cake"), 0);
                }
                if (yes_cheescake_hanar.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(11).concat("cake"),1);

                }else if (no_cheescake_hanar.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(11).concat("cake"), 0);
                }

///////////////////////////////bashi sweet///////////////

                if (yes_hlibard.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("sweet"),1);

                }else if (no_hlibard.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("sweet"), 0);
                }
                if (yes_xshxsh.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("sweet"),1);

                }else if (no_xshxsh.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("sweet"), 0);
                }

                if (yes_lwqmapasha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("sweet"),1);

                }else if (no_lwqmapasha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("sweet"), 0);
                }


                if (yes_basbwsa.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("sweet"),1);

                }else if (no_basbwsa.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("sweet"), 0);
                }



                if (yestiramisu.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("sweet"),1);

                }else if (no_tiramisu.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("sweet"), 0);
                }
                if (yes_shOreio.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("sweet"),1);

                }else if (no_shOrieo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("sweet"), 0);
                }
                if (yes_shLotus.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(6).concat("sweet"),1);

                }else if (no_shLotus.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(6).concat("sweet"), 0);
                }
                if (yes_magnolya.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(7).concat("sweet"),1);

                }else if (no_magnolya.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(7).concat("sweet"), 0);
                }

               // System.out.println(ob.getIntPrefVal(getApplicationContext(),Integer.toString(5).concat("sweet")));
//////////////////////////////bashi kunafa/////////////////////////////////////

                if (yes_bchwk.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("kunafa"),1);
                }else if (no_bchwk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("kunafa"), 0);
                }
                if (yes_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("kunafa"),1);

                }else if (no_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("kunafa"), 0);
                }

                if (yes_fstq_bchwk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("kunafa"),1);

                }else if (no_fstq_bchwk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("kunafa"), 0);
                }


                if (yes_fstq_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("kunafa"),1);

                }else if (no_fstq_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("kunafa"), 0);
                }



                if (yes_nutella_bchwk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("kunafa"),1);

                }else if (no_nutella_bchwk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("kunafa"), 0);
                }
                if (yes_nutella_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("kunafa"),1);

                }else if (no_nutella_wasat.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("kunafa"), 0);
                }


/////////////////////////////bashi crepe/////////////////////////////////////

                if (yes_crepe_sada.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("crepe"),1);
                }else if (no_crepe_sada.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("crepe"), 0);
                }
                if (yes_crepe_moz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("crepe"),1);

                }else if (no_crepe_moz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("crepe"), 0);
                }

                if (yes_crepe_shlk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("crepe"),1);

                }else if (no_crepe_shlk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("crepe"), 0);
                }


                if (yes_crepe_oreo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("crepe"),1);

                }else if (no_crepe_oreo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("crepe"), 0);
                }



                if (yes_crepe_kinder.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("crepe"),1);

                }else if (no_crepe_kinder.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("crepe"), 0);
                }
                if (yes_crepe_mwshakal.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("crepe"),1);

                }else if (no_crepe_mushakal.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("crepe"), 0);
                }

/////////////////////////////bashi sharbati fresh/////////////////////////////////////

                if (yes_freshprtaqal.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("fresh"),1);
                }else if (no_freshprtaqal.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("fresh"), 0);
                }
                if (yes_shirmoz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("fresh"),1);

                }else if (no_shirmoz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("fresh"), 0);
                }
                if (yes_kalak.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("fresh"),1);
                }else if (no_kalak.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("fresh"), 0);
                }
                if (yes_fqox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("fresh"),1);

                }else if (no_fqox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("fresh"), 0);
                }

                ///////////////////////////////////////////////////bashi xwardnaway sard//////////

                if (yes_cola.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("xwardnawa"),1);

                }else if (no_cola.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("xwardnawa"), 0);
                }
                if (yes_sprite.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("xwardnawa"),1);

                }else if (no_sprite.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("xwardnawa"), 0);
                }

                if (yes_tiger.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("xwardnawa"),1);

                }else if (no_tiger.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("xwardnawa"), 0);
                }


                if (yes_maksiky.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("xwardnawa"),1);

                }else if (no_maksiky.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("xwardnawa"), 0);
                }


                if (yes_ice.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("xwardnawa"),1);

                }else if (no_ice.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("xwardnawa"), 0);
                }
   ///////////////////////////////////////////////////bashi xwardnaway garm//////////

                if (yes_qazwan.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("hot"),1);

                }else if (no_qazwan.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("hot"), 0);
                }
                if (yes_turki.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("hot"),1);

                }else if (no_turki.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("hot"), 0);
                }

                if (yes_arabi.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("hot"),1);

                }else if (no_arabi.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("hot"), 0);
                }


                if (yes_esperso.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("hot"),1);

                }else if (no_esperso.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("hot"), 0);
                }


                if (yes_hotChokolet.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("hot"),1);

                }else if (no_hotChokolet.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("hot"), 0);
                }


                if (yes_americano.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("hot"),1);

                }else if (no_americano.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("hot"), 0);
                }


                if (yes_late.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(6).concat("hot"),1);

                }else if (no_late.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(6).concat("hot"), 0);
                }


                if (yes_capocino.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(7).concat("hot"),1);

                }else if (no_capocino.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(7).concat("hot"), 0);
                }
                if (yes_fstq.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(8).concat("hot"),1);

                }else if (no_fstq.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(8).concat("hot"), 0);
                }
                if (yes_gwez.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(9).concat("hot"),1);

                }else if (no_gwez.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(9).concat("hot"), 0);
                }

 ///////////////////////////////bashi mohito///////////////

                if (yes_gelas.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("mohito"),1);

                }else if (no_gelas.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("mohito"), 0);
                }
                if (yes_qox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("mohito"),1);

                }else if (no_qox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("mohito"), 0);
                }

                if (yes_hanar.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("mohito"),1);

                }else if (no_hanar.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("mohito"), 0);
                }


                if (yes_blue.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("mohito"),1);

                }else if (no_blue.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("mohito"), 0);
                }

                if (yes_limo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("mohito"),1);

                }else if (no_limo.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("mohito"), 0);
                }
                if (yes_bluecoraso.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("mohito"),1);

                }else if (no_bluecoraso.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("mohito"), 0);
                }
                if (yes_classic.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(6).concat("mohito"),1);

                }else if (no_classic.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(6).concat("mohito"), 0);
                }


                //////////////////////////////bashi smuzi///////////////

                if (yes_smuzi_shlk.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("smuzi"),1);

                }else if (no_smuzi_shlk.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("smuzi"), 0);
                }
                if (yes_smuzi_blue.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("smuzi"),1);

                }else if (no_smuzi_blue.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("smuzi"), 0);
                }

                if (yes_smuzi_pasha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("smuzi"),1);

                }else if (no_smuzi_pasha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("smuzi"), 0);
                }


                if (yes_smuzi_moz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(3).concat("smuzi"),1);

                }else if (no_smuzi_moz.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(3).concat("smuzi"), 0);
                }

                if (yes_smuzi_gelas.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(4).concat("smuzi"),1);

                }else if (no_smuzi_gelas.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(4).concat("smuzi"), 0);
                }
                if (yes_smuzi_qox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(5).concat("smuzi"),1);

                }else if (no_smuzi_qox.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(5).concat("smuzi"), 0);
                }
                ///////////////////////////////bashi shiriniwshk///////////////

                if (yes_kulicha.isChecked()){
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(0).concat("shirini"),1);

                }else if (no_kulicha.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(0).concat("shirini"), 0);
                }
                if (yes_kunji.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(1).concat("shirini"),1);

                }else if (no_kunji.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(1).concat("shirini"), 0);
                }

                if (yes_shaklama.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(),Integer.toString(2).concat("shirini"),1);

                }else if (no_shaklama.isChecked()) {
                    ob.setIntPrefVal(getApplicationContext(), Integer.toString(2).concat("shirini"), 0);
                }





                startActivity(new Intent(getApplicationContext(), MainActivity.class) );

            }

        });
    }
}