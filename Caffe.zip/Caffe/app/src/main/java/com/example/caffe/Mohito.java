package com.example.caffe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Mohito extends AppCompatActivity {

    int[] image = {R.drawable.mohito_gelas,R.drawable.mohitoqox,R.drawable.mohito_hanar,R.drawable.mohito_bluberry,R.drawable.mohito_limonana,R.drawable.mohito_bluecoraso,R.drawable.classic_mohito};
    String[] mohito_name = {"مۆهیتۆی گێلاس","مۆهیتۆی قۆخ","مۆهیتۆی هەنار","مۆهیتۆی بلوبێری","لیمۆ نەعنا","مۆهیتۆی بلوکۆراسۆ","کلاسیک مۆهیتۆ"};
    String[] mohito_price = {"3000", "3000","3000","3000","3000","3000","3000"};
    String amount[]=new String[7];

    ListView listmohito;
    Button yes;
    TextView mohito_name_list, mohito_amount_list,mohito_price_list;

    SharedPrefManagerSetting obSetting = new SharedPrefManagerSetting();

    SharedPrefManager ob = new SharedPrefManager();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mohito);


        listmohito =  findViewById(R.id.list_mohito);
        yes =  findViewById(R.id.btn_yes);

        for (int i=0;i<mohito_name.length;i++){
            int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(i).concat("mohitoAmount"));
            amount[i]=Integer.toString(get_amount);

        }

       customAdapter customAdapter=new customAdapter();
        listmohito.setAdapter(customAdapter);

        ///////////////////////la main pewistmana//////////////////////
        ob.setIntPrefVal(getApplicationContext(),"list_mohito_chid_num",mohito_name.length);

        ////////////////////////////////////////////////////////////////////////////

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println(listmohito.getChildCount());
                for (int i =0;i<listmohito.getCount();i++){

                    View  v= getViewByPosition(i,listmohito);
                    mohito_name_list=(TextView)v.findViewById(R.id.name);
                    mohito_amount_list =(TextView) v.findViewById(R.id.amount);
                    mohito_price_list =(TextView)v.findViewById(R.id.price);


                    if (!amount[i].equals(0)){
                        ob.setPrefVal(getApplicationContext(),Integer.toString(i).concat("mohitoName"),mohito_name_list.getText().toString());
                        ob.setIntPrefVal(getApplicationContext(),Integer.toString(i).concat("mohitoAmount"),Integer.parseInt(mohito_amount_list.getText().toString()));
                        ob.setIntPrefVal(getApplicationContext(),Integer.toString(i).concat("mohitoPrice"),Integer.parseInt(mohito_price_list.getText().toString()));

                    }

                }

                startActivity(new Intent(getApplicationContext(), MainActivity.class) );


            }
        });
    }



    public View getViewByPosition(int position, ListView list){
        final int firstListItemPostion=list.getFirstVisiblePosition();
        final int lastListItemPostion=firstListItemPostion+list.getChildCount()-1;
        if (position<firstListItemPostion || position>lastListItemPostion){
            return list.getAdapter().getView(position,list.getChildAt(position),list);
        }else {
            final  int childIndex=position-firstListItemPostion;
            return list.getChildAt(childIndex);
        }
    }





    class customAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return mohito_name.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }



        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            view = getLayoutInflater().inflate(R.layout.activity_custom_listview, null);
            int get_avilable=obSetting.getIntPrefVal(getApplicationContext(),Integer.toString(i).concat("mohito"));

            ImageView imageView = (ImageView) view.findViewById(R.id.img);
            TextView  cake_name_list = (TextView) view.findViewById(R.id.name);
            TextView cake_price_list = (TextView) view.findViewById(R.id.price);
            ImageButton plus = (ImageButton) view.findViewById(R.id.b_plus);
            ImageButton minus = (ImageButton) view.findViewById(R.id.b_minus);
            TextView cake_amount_list=view.findViewById(R.id.amount);




            imageView.setImageResource(image[i]);
            cake_name_list.setText(mohito_name[i]);
            if (get_avilable==0){
                cake_name_list.setTextColor(Color.RED);
            }
            cake_price_list.setText(mohito_price[i]);
            cake_amount_list.setText(amount[i]);


            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (get_avilable==0) {
                        show_Alert();
                    }else{
                    int get_amount = Integer.parseInt(cake_amount_list.getText().toString());
                    get_amount++;
                    cake_amount_list.setText(Integer.toString(get_amount));
                    amount[i]=Integer.toString(get_amount);
                }}
            });

            minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int get_amount = Integer.parseInt(cake_amount_list.getText().toString());
                    if (get_amount < 0 || get_amount == 0) {
                        cake_amount_list.setText(Integer.toString(get_amount));
                        amount[i]=Integer.toString(get_amount);

                    } else {
                        get_amount--;
                        cake_amount_list.setText(Integer.toString(get_amount));
                        amount[i]=Integer.toString(get_amount);

                    }

                }


            });




            return view;


        }


    }


    ///////////////////////////////////////////////////////////////////

    public  void show_Alert(){

        AlertDialog.Builder Alert=new AlertDialog.Builder(Mohito.this);
        // Alert.setTitle("ڕونکردنەوە");
        Alert.setMessage("لە ئێستادا بەردەست نیە");
        Alert.show();
    }
}