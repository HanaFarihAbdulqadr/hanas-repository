package com.example.caffe;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.mazenrashed.printooth.Printooth;
import com.mazenrashed.printooth.data.converter.ArabicConverter;
import com.mazenrashed.printooth.data.printable.Printable;
import com.mazenrashed.printooth.data.printable.RawPrintable;
import com.mazenrashed.printooth.data.printable.TextPrintable;
import com.mazenrashed.printooth.data.printer.DefaultPrinter;
import com.mazenrashed.printooth.ui.ScanningActivity;
import com.mazenrashed.printooth.utilities.Printing;
import com.mazenrashed.printooth.utilities.PrintingCallback;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements PrintingCallback {
ImageButton cake,sweet,kunafa,crepe,xwardnaway_garm,xwardnaway_sard,juce,mohito,smwzy,shirini_wshk;
TextView setting;
Button show_order,print,unpair_pair;

 SharedPrefManager ob=new SharedPrefManager();

 Printing printing;
    String all_orders=null;
    String all_price="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         cake =(ImageButton) findViewById(R.id.relative_cake);
         sweet =(ImageButton) findViewById(R.id.relative_sweets);
        kunafa =findViewById(R.id.relative_kunafa);
        crepe =findViewById(R.id.relative_crepe);
        xwardnaway_garm =findViewById(R.id.relative_garm);
        xwardnaway_sard =findViewById(R.id.relative_sard);
        juce =findViewById(R.id.relative_juce);
        mohito =findViewById(R.id.relative_mohito);
        smwzy =findViewById(R.id.relative_smwzy);
        shirini_wshk =findViewById(R.id.relative_shirini_wshk);

         setting =(TextView) findViewById(R.id.btn_setting);
         show_order = (Button) findViewById(R.id.btn_show);

         //////////////////////print/////////////////////////////

        intView();

         ///////////////////////////////////////////////////////////////////////////

         show_order.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 ///////////////////////////////////////////////////////////bashi cake///////
                 String all_cake_order="";
                 int all_cake_price=0;

                 int get_cake_child=ob.getIntPrefVal(getApplicationContext(),"list_cake_chid_num");

                for (int iCake=0;iCake<get_cake_child;iCake++){
                    int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iCake).concat("cakeAmount"));
                    if (get_amount!=0) {
                        String get_cake_name = ob.getPrefVal(getApplicationContext(), Integer.toString(iCake).concat("cakeName"));
                        int get_cake_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(iCake).concat("cakePrice"));

                        String concate_cake_name = Integer.toString(get_amount) + " " + get_cake_name;
                        all_cake_price=(get_cake_price*get_amount) +all_cake_price;
                        all_cake_order =   concate_cake_name  + "\n" + all_cake_order;


                    }

                }


           ////////////////////////////////////////////////bashi sweets////////////
                 String all_sweet_order="";
                 int all_sweet_price=0;

                 int get_sweet_child=ob.getIntPrefVal(getApplicationContext(),"list_sweet_chid_num");

                 for (int iSweet=0;iSweet<get_sweet_child;iSweet++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iSweet).concat("sweetAmount"));
                     if (get_amount!=0) {
                         String get_sweet_name = ob.getPrefVal(getApplicationContext(), Integer.toString(iSweet).concat("sweetName"));
                         int get_sweet_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(iSweet).concat("sweetPrice"));

                         String concate_sweet_name = Integer.toString(get_amount) + " " + get_sweet_name;
                         all_sweet_price=(get_sweet_price*get_amount) +all_sweet_price;
                         all_sweet_order =   concate_sweet_name  + "\n" + all_sweet_order;


                     }

                 }


         ////////////////////////////////bashi kunafa/////////////////////////////////

                 String all_kunafa_order="";
                 int all_kunafa_price=0;

                 int get_kunafa_child=ob.getIntPrefVal(getApplicationContext(),"list_kunafa_chid_num");

                 for (int iKunafa=0;iKunafa<get_kunafa_child;iKunafa++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iKunafa).concat("kunafaAmount"));
                     if (get_amount!=0) {
                         String get_kunafa_name = ob.getPrefVal(getApplicationContext(), Integer.toString(iKunafa).concat("kunafaName"));
                         int get_kunafa_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(iKunafa).concat("kunafaPrice"));

                         String concate_kunafa_name = Integer.toString(get_amount) + " " + get_kunafa_name;
                         all_kunafa_price=(get_kunafa_price*get_amount) +all_kunafa_price;
                         all_kunafa_order =   concate_kunafa_name  + "\n" + all_kunafa_order;


                     }

                 }

       /////////////////////////////bashi crepe///////////////////////////////////////////
                 String all_crepe_order="";
                 int all_crepe_price=0;

                 int get_crepe_child=ob.getIntPrefVal(getApplicationContext(),"list_crepe_chid_num");

                 for (int iCrepe=0;iCrepe<get_crepe_child;iCrepe++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(iCrepe).concat("crepeAmount"));
                     if (get_amount!=0) {
                         String get_crepe_name = ob.getPrefVal(getApplicationContext(), Integer.toString(iCrepe).concat("crepeName"));
                         int get_crepe_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(iCrepe).concat("crepePrice"));

                         String concate_crepe_name = Integer.toString(get_amount) + " " + get_crepe_name;
                         all_crepe_price=(get_crepe_price*get_amount) +all_crepe_price;
                         all_crepe_order =   concate_crepe_name  + "\n" + all_crepe_order;


                     }

                 }

 //////////////////////////////bashi xwardnaway sard////////////////////////////////////////////////
                 String all_xwardnawa_order="";
                 int all_xwardnawa_price=0;

                 int get_xwardnawa_child=ob.getIntPrefVal(getApplicationContext(),"list_xwardnawa_chid_num");

                 for (int ixwardnawa=0;ixwardnawa<get_xwardnawa_child;ixwardnawa++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(ixwardnawa).concat("xwardnawaAmount"));
                     if (get_amount!=0) {
                         String get_xwardnawa_name = ob.getPrefVal(getApplicationContext(), Integer.toString(ixwardnawa).concat("xwardnawaName"));
                         int get_xwardnawa_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ixwardnawa).concat("xwardnawaPrice"));

                         String concate_xwardnawa_name = Integer.toString(get_amount) + " " + get_xwardnawa_name;
                         all_xwardnawa_price=(get_xwardnawa_price*get_amount) +all_xwardnawa_price;
                         all_xwardnawa_order =   concate_xwardnawa_name  + "\n" + all_xwardnawa_order;


                     }

                 }


///////////////////////////////bashi hotDrink////////////////////////////////////////////////
                 String all_hotDrink_order="";
                 int all_hotDrink_price=0;

                 int get_hotDrink_child=ob.getIntPrefVal(getApplicationContext(),"list_hotDrink_chid_num");

                 for (int ihotDrink=0;ihotDrink<get_hotDrink_child;ihotDrink++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(ihotDrink).concat("hotDrinkAmount"));
                     if (get_amount!=0) {
                         String get_hotDrink_name = ob.getPrefVal(getApplicationContext(), Integer.toString(ihotDrink).concat("hotDrinkName"));
                         int get_hotDrink_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ihotDrink).concat("hotDrinkPrice"));

                         String concate_hotDrink_name = Integer.toString(get_amount) + " " + get_hotDrink_name;
                         all_hotDrink_price=(get_hotDrink_price*get_amount) +all_hotDrink_price;
                         all_hotDrink_order =   concate_hotDrink_name  + "\n" + all_hotDrink_order;


                     }

                 }
///////////////////////////////bashi juce////////////////////////////////////////////////
                 String all_juce_order="";
                 int all_juce_price=0;

                 int get_juce_child=ob.getIntPrefVal(getApplicationContext(),"list_juce_chid_num");

                 for (int ijuce=0;ijuce<get_juce_child;ijuce++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(ijuce).concat("juceAmount"));
                     if (get_amount!=0) {
                         String get_juce_name = ob.getPrefVal(getApplicationContext(), Integer.toString(ijuce).concat("juceName"));
                         int get_juce_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ijuce).concat("jucePrice"));

                         String concate_juce_name = Integer.toString(get_amount) + " " + get_juce_name;
                         all_juce_price=(get_juce_price*get_amount) +all_juce_price;
                         all_juce_order =   concate_juce_name  + "\n" + all_juce_order;


                     }

                 }

///////////////////////////////bashi mohito////////////////////////////////////////////////
                 String all_mohito_order="";
                 int all_mohito_price=0;

                 int get_mohito_child=ob.getIntPrefVal(getApplicationContext(),"list_mohito_chid_num");

                 for (int imohito=0;imohito<get_mohito_child;imohito++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(imohito).concat("mohitoAmount"));
                     if (get_amount!=0) {
                         String get_mohito_name = ob.getPrefVal(getApplicationContext(), Integer.toString(imohito).concat("mohitoName"));
                         int get_mohito_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(imohito).concat("mohitoPrice"));

                         String concate_mohito_name = Integer.toString(get_amount) + " " + get_mohito_name;
                         all_mohito_price=(get_mohito_price*get_amount) +all_mohito_price;
                         all_mohito_order =   concate_mohito_name  + "\n" + all_mohito_order;


                     }

                 }


///////////////////////////////bashi smuzi////////////////////////////////////////////////
                 String all_smuzi_order="";
                 int all_smuzi_price=0;

                 int get_smuzi_child=ob.getIntPrefVal(getApplicationContext(),"list_smuzi_chid_num");

                 for (int ismuzi=0;ismuzi<get_smuzi_child;ismuzi++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(ismuzi).concat("smuziAmount"));
                     if (get_amount!=0) {
                         String get_smuzi_name = ob.getPrefVal(getApplicationContext(), Integer.toString(ismuzi).concat("smuziName"));
                         int get_smuzi_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ismuzi).concat("smuziPrice"));

                         String concate_smuzi_name = Integer.toString(get_amount) + " " + get_smuzi_name;
                         all_smuzi_price=(get_smuzi_price*get_amount) +all_smuzi_price;
                         all_smuzi_order =   concate_smuzi_name  + "\n" + all_smuzi_order;


                     }

                 }
///////////////////////////////bashi shiriniwshk////////////////////////////////////////////////
                 String all_shirini_order="";
                 int all_shirini_price=0;

                 int get_shirini_child=ob.getIntPrefVal(getApplicationContext(),"list_shirini_chid_num");

                 for (int ishirini=0;ishirini<get_shirini_child;ishirini++){
                     int get_amount=ob.getIntPrefVal(getApplicationContext(),Integer.toString(ishirini).concat("shiriniAmount"));
                     if (get_amount!=0) {
                         String get_shirini_name = ob.getPrefVal(getApplicationContext(), Integer.toString(ishirini).concat("shiriniName"));
                         int get_shirini_price = ob.getIntPrefVal(getApplicationContext(), Integer.toString(ishirini).concat("shiriniPrice"));

                         String concate_shirini_name = Integer.toString(get_amount) + " " + get_shirini_name;
                         all_shirini_price=(get_shirini_price*get_amount) +all_shirini_price;
                         all_shirini_order =   concate_shirini_name  + "\n" + all_shirini_order;


                     }

                 }
/////////////////////////////////////////////////////////////////////////////////////////////////
                 all_orders = all_cake_order +"\n"+all_sweet_order+"\n"+all_kunafa_order+"\n"
                         +all_crepe_order+"\n"+all_xwardnawa_order+"\n"+all_hotDrink_order+"\n"+all_juce_order
                         +"\n"+all_mohito_order+"\n"+all_smuzi_order +"\n"+all_shirini_order;
                 int sum_price=all_sweet_price+all_cake_price+all_kunafa_price+all_crepe_price+
                         all_xwardnawa_price+ all_hotDrink_price+all_juce_price+all_mohito_price+all_smuzi_price+all_shirini_price;

                 all_price="کۆی گشتی"+": " +Integer.toString(sum_price)    ;

                 show_Alert(all_orders,all_price);





                }





         });


////////////////////////////////////////////////////////////////////////

        cake.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Cake.class) );
            }
        });

        sweet.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Sweets.class) );
            }
        });

        kunafa.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Kunafa.class) );
            }
        });

        crepe.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Crepe.class) );
            }
        });
        xwardnaway_garm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), HotDrink.class) );
            }
        });


        xwardnaway_sard.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), XwardnawaySard.class) );
            }
        });
        juce.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Juce.class) );
            }
        });

        mohito.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), Mohito.class) );
            }
        });
        smwzy.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), smuzi.class) );
            }
        });

        shirini_wshk.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getApplicationContext(), shiriniwshk.class) );
            }
        });



    }




    public void setting_function(View v){

        startActivity(new Intent(getApplicationContext(), Login.class) );
    }




    public  void show_Alert(String all_order,String all_price){
        AlertDialog.Builder Alert=new AlertDialog.Builder(MainActivity.this);
        Alert.setTitle("داواکارییەکان");
        Alert.setMessage(all_order + "\n" +all_price);
        Alert.setPositiveButton("باشە", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        Alert.setNegativeButton("سڕینەوەی داواکارییەکان", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ob.clearShardPreferences(getApplicationContext());
                Toast.makeText(MainActivity.this, "داواکارییەکانی پێشوو بە سەرکەوتووی سڕایەوە", Toast.LENGTH_SHORT).show();
            }
        });
        Alert.show();
    }











    ///////////////////////////////////////////////////////////
    private void intView() {

        print=findViewById(R.id.btn_print);
        unpair_pair=findViewById(R.id.btn_unpair_pair);
        if(printing!=null){
            printing.setPrintingCallback(this);
        }
    unpair_pair.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (Printooth.INSTANCE.hasPairedPrinter())
            Printooth.INSTANCE.removeCurrentPrinter();
        else {
            startActivityForResult(new Intent(MainActivity.this, ScanningActivity.class),ScanningActivity.SCANNING_FOR_PRINTER);
            changPainrAndUnpair();
        }
    }
});

     print.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             if (!Printooth.INSTANCE.hasPairedPrinter())
                 startActivityForResult(new Intent(MainActivity.this,ScanningActivity.class),ScanningActivity.SCANNING_FOR_PRINTER);
             else
                 printingText();
         }
     });


     changPainrAndUnpair();
    }

    private void printingText() {

        ArrayList<Printable> printables=new ArrayList<>();
        printables.add(new RawPrintable.Builder(new byte[]{27,100,4}).build());
        printables.add(new TextPrintable.Builder().setText(all_orders+"\n"+all_price)
         .setCharacterCode(DefaultPrinter.Companion.getCHARCODE_PC1252()).build());

        printing.print(printables);

    }


    private  void changPainrAndUnpair(){
        if (Printooth.INSTANCE.hasPairedPrinter())
            unpair_pair.setText(new StringBuilder("Unpair")
               .append(Printooth.INSTANCE.getPairedPrinter().getName()).toString());

        else
            unpair_pair.setText("Pair with printer");
    }

    @Override
    public void connectingWithPrinter() {
        Toast.makeText(this, "Connecting to printer", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void connectionFailed(@NonNull String s) {
        Toast.makeText(this, "Failed"+s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(@NonNull String s) {
        Toast.makeText(this, "Error"+s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onMessage(@NonNull String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void printingOrderSentSuccessfully() {
        Toast.makeText(this, "order sent to printer", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==ScanningActivity.SCANNING_FOR_PRINTER && resultCode== Activity.RESULT_OK)
            intPrinting();
        changPainrAndUnpair();
    }

    private void intPrinting() {
        if(!Printooth.INSTANCE.hasPairedPrinter())
            printing=Printooth.INSTANCE.printer();
        if (printing!=null)
            printing.setPrintingCallback(this);

    }
}////////////////////////end Class MainActivity////////////////////////

